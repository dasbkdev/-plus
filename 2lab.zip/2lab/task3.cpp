#include "../common/input.h"
#include <fstream>

// Стек: последним добавили вагон — первым его забрали.
// Указатель next связывает один вагон со следующим.
class Stack {
private:
    struct Node {
        int wagon;
        Node* next;
    };
    Node* top = nullptr;

public:
    void push(int wagon) {
        Node* node = new Node;
        node->wagon = wagon;
        node->next = top; // Новый узел указывает на прежнюю вершину.
        top = node;
    }

    bool pop(int& wagon) {
        // Ссылка & позволяет вернуть снятый вагон через параметр функции.
        if (top == nullptr) {
            return false;
        }
        Node* old = top;
        wagon = top->wagon;
        top = top->next;
        delete old; // Освобождаем память удалённого узла.
        return true;
    }

    void clear() {
        int wagon;
        // pop сам удаляет узел. Повторяем, пока стек не станет пустым.
        while (pop(wagon)) {
        }
    }

    void show() const {
        cout << "Вершина -> ";
        Node* current = top;
        while (current != nullptr) {
            cout << current->wagon << ' ';
            current = current->next;
        }
        if (top == nullptr) {
            cout << "пусто";
        }
        cout << '\n';
    }

    bool input() {
        // Временный массив нужен, чтобы ошибка файла не испортила старый стек.
        int wagons[100], count;
        int mode = readInt("1 - клавиатура, 2 - файл: ", 1, 2);
        if (mode == 1) {
            count = readInt("Количество вагонов (0..100): ", 0, 100);
            for (int i = 0; i < count; i++) {
                wagons[i] = readInt("Тип вагона (1 или 2): ", 1, 2);
            }
        } else {
            string path = readText("Путь к файлу: ", 250);
            ifstream file(path);
            // Сначала читаем количество, затем ровно столько вагонов.
            if (!file || !(file >> count) || count < 0 || count > 100) {
                cout << "Ошибка открытия файла или количества вагонов.\n";
                return false;
            }
            for (int i = 0; i < count; i++) {
                if (!(file >> wagons[i]) || (wagons[i] != 1 && wagons[i] != 2)) {
                    cout << "Ошибка: каждый вагон должен иметь тип 1 или 2.\n";
                    return false;
                }
            }
            string extra;
            if (file >> extra) {
                cout << "Ошибка: лишние данные в файле.\n";
                return false;
            }
        }
        clear(); // Старый состав заменяется только после проверки всех данных.
        for (int i = 0; i < count; i++) {
            push(wagons[i]);
        }
        return true;
    }

    void divide(Stack& first, Stack& second) {
        // Перед новым разделением очищаем предыдущие результаты.
        first.clear();
        second.clear();
        int wagon;
        while (pop(wagon)) {
            // Тип вагона определяет направление.
            if (wagon == 1) {
                first.push(wagon);
            } else {
                second.push(wagon);
            }
        }
    }

    // При обычном выходе из main освобождаем оставшиеся узлы.
    ~Stack() {
        clear();
    }
};

int main() {
    Stack train, first, second;
    while (true) {
        cout << "\n1 - сформировать состав, 2 - показать, 3 - разделить, 0 - выход\n";
        int menu = readInt("Выбор: ", 0, 3);
        if (menu == 0) {
            break;
        }
        if (menu == 1) {
            bool loaded = train.input();
            if (loaded) {
                first.clear();
                second.clear();
            }
        }
        if (menu == 2) {
            cout << "Общий: ";
            train.show();
        }
        if (menu == 3) {
            cout << "До разделения: ";
            train.show();
            train.divide(first, second);
            cout << "Общий после разделения: ";
            train.show();
            cout << "Направление 1: ";
            first.show();
            cout << "Направление 2: ";
            second.show();
        }
    }
}
